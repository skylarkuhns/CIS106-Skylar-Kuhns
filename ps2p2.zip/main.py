#input phase
lname = input("Enter student last name")
midterm = float(input("Enter Midterm Score"))
Final = float(input("Enter Final Score"))

#process phase
total = midterm + Final

#output phase
print("Student:   ", lname)
print("total points earned ", total )
